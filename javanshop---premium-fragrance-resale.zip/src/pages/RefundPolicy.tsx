import { RefreshCcw, Heart, ShieldCheck } from 'lucide-react';

export const RefundPolicy = () => {
  return (
    <div className="bg-white">
      <div className="bg-gray-50 py-24 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-5xl font-black uppercase tracking-tighter mb-6">Refund Policy</h1>
          <p className="text-gray-500 uppercase tracking-widest text-sm font-bold">100% Satisfaction Guaranteed</p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-24">
        <div className="prose prose-lg max-w-none">
          <div className="flex items-center gap-4 mb-8 p-6 bg-green-50 border border-green-100 rounded-3xl">
            <RefreshCcw className="w-8 h-8 text-green-600" />
            <div>
              <h3 className="text-xl font-black uppercase tracking-tight m-0">All Money Back</h3>
              <p className="text-gray-600 m-0">We offer a full refund policy—essentially all your money back if you're not happy.</p>
            </div>
          </div>

          <h2 className="text-3xl font-black uppercase tracking-tighter mb-6">Our Promise</h2>
          <p className="text-gray-600 leading-relaxed mb-8">
            We want you to love your new scent. If for any reason you are not completely satisfied with your purchase, 
            we make it easy to get your money back. No complicated forms, no hidden fees.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            <div className="p-8 bg-gray-50 border border-gray-100 rounded-3xl">
              <Heart className="w-10 h-10 mb-4 text-red-500" />
              <h4 className="text-lg font-black uppercase tracking-tight mb-2">No Questions Asked</h4>
              <p className="text-sm text-gray-500">If it's not the right fit for you, just let us know. We value your satisfaction above all else.</p>
            </div>
            <div className="p-8 bg-gray-50 border border-gray-100 rounded-3xl">
              <ShieldCheck className="w-10 h-10 mb-4 text-[#003366]" />
              <h4 className="text-lg font-black uppercase tracking-tight mb-2">Secure Returns</h4>
              <p className="text-sm text-gray-500">Your refund is processed securely back to your original payment method.</p>
            </div>
          </div>

          <h3 className="text-2xl font-black uppercase tracking-tighter mb-4">How to Start a Return</h3>
          <p className="text-gray-600 leading-relaxed mb-4">
            Simply email us at <span className="font-bold text-black">jakeconjohn5@gmail.com</span> with your order number 
            and we'll provide you with a return shipping label. Once we receive the item, your refund will be 
            processed immediately.
          </p>
          
          <p className="text-gray-400 text-sm italic mt-12 border-t pt-8">
            Last updated: March 2026
          </p>
        </div>
      </div>
    </div>
  );
};
