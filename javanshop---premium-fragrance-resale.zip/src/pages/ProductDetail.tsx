import { useParams, Link } from 'react-router-dom';
import { Star, ShieldCheck, Truck, RotateCcw, Zap, Clock } from 'lucide-react';
import { motion } from 'motion/react';
import { PRODUCTS } from '../constants';
import { Button } from '../components/Button';
import { ProductCard } from '../components/ProductCard';

export const ProductDetail = () => {
  const { id } = useParams();
  const product = PRODUCTS.find(p => p.id === id);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-black mb-4">Product Not Found</h1>
          <Link to="/shop">
            <Button>Back to Shop</Button>
          </Link>
        </div>
      </div>
    );
  }

  const discount = Math.round(((product.retailPrice - product.price) / product.retailPrice) * 100);
  const relatedProducts = PRODUCTS.filter(p => p.type === product.type && p.id !== product.id).slice(0, 4);

  return (
    <div className="bg-white">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Product Image */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="relative aspect-[3/4] bg-white overflow-hidden rounded-3xl p-16"
          >
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-contain"
              referrerPolicy="no-referrer"
            />
            <div className="absolute top-6 left-6 bg-[#003366] text-white px-4 py-2 text-sm font-black uppercase tracking-widest">
              -{discount}% OFF
            </div>
          </motion.div>

          {/* Product Info */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex flex-col"
          >
            <div className="mb-6">
              <p className="text-sm text-gray-500 uppercase tracking-[0.2em] font-bold mb-2">{product.brand}</p>
              <h1 className="text-4xl md:text-5xl font-black uppercase tracking-tighter mb-4">{product.name}</h1>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${i < Math.floor(product.rating) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
                    />
                  ))}
                  <span className="text-sm font-bold ml-2">{product.rating}</span>
                </div>
                <span className="text-gray-300">|</span>
                <span className="text-sm text-gray-500 font-bold uppercase tracking-widest">{product.reviewsCount} Reviews</span>
              </div>
            </div>

            <div className="mb-8 p-6 bg-gray-50 border border-gray-100 rounded-[2rem]">
              <div className="flex items-baseline gap-4 mb-2">
                <span className="text-4xl font-black text-black">${product.price}</span>
                <span className="text-xl text-gray-400 line-through">${product.retailPrice}</span>
                <span className="text-sm font-bold text-[#003366] uppercase tracking-widest">Save ${product.retailPrice - product.price}</span>
              </div>
              <p className="text-xs text-gray-500 uppercase tracking-widest font-bold">Free shipping on this item</p>
            </div>

            {product.stockCount < 10 && (
              <div className="mb-6 flex items-center gap-2 text-red-600 font-bold uppercase tracking-widest text-sm">
                <Clock className="w-4 h-4" />
                Hurry! Only {product.stockCount} left in stock
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <Button 
                variant="outline" 
                className="w-full gap-3 py-5" 
                size="lg"
                onClick={() => {
                  if (product.stripeLink) {
                    window.location.href = product.stripeLink;
                  }
                }}
              >
                <Zap className="w-5 h-5" />
                Buy It Now
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12 border-y border-gray-100 py-8">
              <div className="flex items-center gap-3">
                <ShieldCheck className="w-6 h-6 text-gray-400" />
                <div>
                  <p className="text-xs font-black uppercase tracking-widest">100% Authentic</p>
                  <p className="text-[10px] text-gray-500 uppercase">Guaranteed</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Truck className="w-6 h-6 text-gray-400" />
                <div>
                  <p className="text-xs font-black uppercase tracking-widest">Fast Shipping</p>
                  <p className="text-[10px] text-gray-500 uppercase">2-4 Business Days</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <RotateCcw className="w-6 h-6 text-gray-400" />
                <div>
                  <p className="text-xs font-black uppercase tracking-widest">Easy Returns</p>
                  <p className="text-[10px] text-gray-500 uppercase">30 Day Window</p>
                </div>
              </div>
            </div>

            <div className="space-y-8">
              <div>
                <h3 className="text-lg font-black uppercase tracking-widest mb-4">Description</h3>
                <p className="text-gray-600 leading-relaxed">{product.description}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-sm font-black uppercase tracking-widest mb-4 border-b pb-2">Fragrance Notes</h3>
                  <div className="space-y-4">
                    <div>
                      <p className="text-[10px] font-black uppercase text-gray-400 mb-1">Top Notes</p>
                      <p className="text-sm font-bold uppercase tracking-widest">{product.notes.top.join(', ')}</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-black uppercase text-gray-400 mb-1">Middle Notes</p>
                      <p className="text-sm font-bold uppercase tracking-widest">{product.notes.middle.join(', ')}</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-black uppercase text-gray-400 mb-1">Base Notes</p>
                      <p className="text-sm font-bold uppercase tracking-widest">{product.notes.base.join(', ')}</p>
                    </div>
                  </div>
                </div>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-black uppercase tracking-widest mb-4 border-b pb-2">Details</h3>
                    <div className="space-y-4">
                      <div>
                        <p className="text-[10px] font-black uppercase text-gray-400 mb-1">Longevity</p>
                        <p className="text-sm font-bold uppercase tracking-widest">{product.longevity}</p>
                      </div>
                      <div>
                        <p className="text-[10px] font-black uppercase text-gray-400 mb-1">Best Occasion</p>
                        <p className="text-sm font-bold uppercase tracking-widest">{product.occasion}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Related Products */}
        <div className="mt-24">
          <h2 className="text-3xl font-black uppercase tracking-tighter mb-12">You May Also Like</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {relatedProducts.map(p => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </div>

      {/* Sticky Buy Now (Mobile) */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 z-40 flex items-center justify-between gap-4">
        <div>
          <p className="text-xs text-gray-500 uppercase font-bold">{product.name}</p>
          <p className="text-lg font-black">${product.price}</p>
        </div>
        <Button 
          className="flex-1"
          onClick={() => {
            if (product.stripeLink) {
              window.location.href = product.stripeLink;
            }
          }}
        >
          Buy It Now
        </Button>
      </div>
    </div>
  );
};
