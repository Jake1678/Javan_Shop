import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Filter, ChevronDown, Search } from 'lucide-react';
import { ProductCard } from '../components/ProductCard';
import { PRODUCTS } from '../constants';

export const Shop = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [activeType, setActiveType] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState(searchParams.get('q') || '');

  useEffect(() => {
    const query = searchParams.get('q');
    if (query !== null) {
      setSearchQuery(query);
    }
  }, [searchParams]);

  const handleSearchChange = (val: string) => {
    setSearchQuery(val);
    if (val) {
      setSearchParams({ q: val });
    } else {
      setSearchParams({});
    }
  };

  const types = ['Fresh', 'Sweet', 'Woody', 'Spicy'];

  const filteredProducts = PRODUCTS.filter(p => {
    const matchesType = activeType ? p.type === activeType : true;
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         p.brand.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-gray-50 py-12 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4">
          <h1 className="text-4xl font-black uppercase tracking-tighter mb-2">Shop All Fragrances</h1>
          <p className="text-gray-500 uppercase tracking-widest text-sm font-bold">Authentic designer scents at wholesale prices</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="flex flex-col lg:flex-row gap-12">
          {/* Sidebar Filters */}
          <aside className="w-full lg:w-64 flex-shrink-0">
            <div className="sticky top-32">
              <div className="mb-8">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search fragrances..."
                    value={searchQuery}
                    onChange={(e) => handleSearchChange(e.target.value)}
                    className="w-full border-2 border-gray-200 px-4 py-3 pl-10 outline-none focus:border-black transition-colors rounded-3xl"
                  />
                  <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                </div>
              </div>

              <div className="mb-8">
                <h3 className="text-sm font-black uppercase tracking-widest mb-4 flex items-center justify-between">
                  Fragrance Type
                  <ChevronDown className="w-4 h-4" />
                </h3>
                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => setActiveType(null)}
                    className={`text-left py-2 px-4 text-sm font-bold uppercase tracking-widest transition-colors ${
                      activeType === null ? 'bg-black text-white' : 'hover:bg-gray-100'
                    }`}
                  >
                    All Types
                  </button>
                  {types.map(type => (
                    <button
                      key={type}
                      onClick={() => setActiveType(type)}
                      className={`text-left py-2 px-4 text-sm font-bold uppercase tracking-widest transition-colors ${
                        activeType === type ? 'bg-black text-white' : 'hover:bg-gray-100'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              <div className="mb-8">
                <h3 className="text-sm font-black uppercase tracking-widest mb-4 flex items-center justify-between">
                  Price Range
                  <ChevronDown className="w-4 h-4" />
                </h3>
                <div className="flex flex-col gap-2">
                  <label className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest cursor-pointer">
                    <input type="checkbox" className="w-4 h-4 accent-black" />
                    Under $50
                  </label>
                  <label className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest cursor-pointer">
                    <input type="checkbox" className="w-4 h-4 accent-black" />
                    $50 - $100
                  </label>
                  <label className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest cursor-pointer">
                    <input type="checkbox" className="w-4 h-4 accent-black" />
                    $100 - $200
                  </label>
                  <label className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest cursor-pointer">
                    <input type="checkbox" className="w-4 h-4 accent-black" />
                    $200+
                  </label>
                </div>
              </div>
            </div>
          </aside>

          {/* Product Grid */}
          <main className="flex-1">
            <div className="flex justify-between items-center mb-8">
              <p className="text-sm text-gray-500 uppercase tracking-widest font-bold">
                Showing {filteredProducts.length} products
              </p>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold uppercase tracking-widest">Sort by:</span>
                <select className="border-none bg-transparent font-black uppercase tracking-widest text-sm outline-none cursor-pointer">
                  <option>Popularity</option>
                  <option>Price: Low to High</option>
                  <option>Price: High to Low</option>
                  <option>Newest</option>
                </select>
              </div>
            </div>

            {filteredProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredProducts.map(product => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="text-center py-24">
                <Search className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                <h3 className="text-xl font-bold uppercase tracking-widest">No products found</h3>
                <p className="text-gray-500">Try adjusting your filters or search query</p>
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
};
