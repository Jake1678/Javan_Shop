import { Mail, Phone, MapPin, Send } from 'lucide-react';
import { Button } from '../components/Button';

export const Contact = () => {
  return (
    <div className="bg-white">
      <div className="bg-gray-50 py-24 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-5xl font-black uppercase tracking-tighter mb-6">Contact Us</h1>
          <p className="text-gray-500 uppercase tracking-widest text-sm font-bold">We're here to help with any questions</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-24">
          <div>
            <h2 className="text-3xl font-black uppercase tracking-tighter mb-8">Get in Touch</h2>
            <p className="text-gray-600 mb-12 leading-relaxed">
              Have a question about a specific fragrance? Need help with an order? Our team of fragrance experts is ready to assist you.
            </p>

            <div className="space-y-8">
              <div className="flex items-start gap-6">
                <div className="w-12 h-12 bg-gray-100 flex items-center justify-center flex-shrink-0 rounded-2xl">
                  <Mail className="w-6 h-6 text-[#003366]" />
                </div>
                <div>
                  <h4 className="text-sm font-black uppercase tracking-widest mb-1">Email Us</h4>
                  <p className="text-gray-600">jakeconjohn5@gmail.com</p>
                  <p className="text-xs text-gray-400 mt-1 uppercase">Response within 24 hours</p>
                </div>
              </div>
              <div className="flex items-start gap-6">
                <div className="w-12 h-12 bg-gray-100 flex items-center justify-center flex-shrink-0 rounded-2xl">
                  <Phone className="w-6 h-6 text-[#003366]" />
                </div>
                <div>
                  <h4 className="text-sm font-black uppercase tracking-widest mb-1">Call Us</h4>
                  <p className="text-gray-600">937-499-3698</p>
                  <p className="text-xs text-gray-400 mt-1 uppercase">Mon-Fri: 9am - 6pm EST</p>
                </div>
              </div>
              <div className="flex items-start gap-6">
                <div className="w-12 h-12 bg-gray-100 flex items-center justify-center flex-shrink-0 rounded-2xl">
                  <MapPin className="w-6 h-6 text-[#003366]" />
                </div>
                <div>
                  <h4 className="text-sm font-black uppercase tracking-widest mb-1">Our Office</h4>
                  <p className="text-gray-600">Southwest Ohio</p>
                  <p className="text-xs text-gray-400 mt-1 uppercase">Distribution Center</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 p-10 border border-gray-100 rounded-[2.5rem]">
            <h3 className="text-2xl font-black uppercase tracking-tighter mb-8">Send a Message</h3>
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-500">Full Name</label>
                  <input
                    type="text"
                    placeholder="John Doe"
                    className="w-full bg-white border-2 border-gray-200 px-4 py-3 outline-none focus:border-black transition-colors rounded-2xl"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-500">Email Address</label>
                  <input
                    type="email"
                    placeholder="john@example.com"
                    className="w-full bg-white border-2 border-gray-200 px-4 py-3 outline-none focus:border-black transition-colors rounded-2xl"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-500">Subject</label>
                <input
                  type="text"
                  placeholder="Order Inquiry"
                  className="w-full bg-white border-2 border-gray-200 px-4 py-3 outline-none focus:border-black transition-colors rounded-2xl"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-500">Message</label>
                <textarea
                  rows={5}
                  placeholder="How can we help you?"
                  className="w-full bg-white border-2 border-gray-200 px-4 py-3 outline-none focus:border-black transition-colors resize-none rounded-2xl"
                ></textarea>
              </div>
              <Button className="w-full gap-3">
                <Send className="w-4 h-4" />
                Send Message
              </Button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
