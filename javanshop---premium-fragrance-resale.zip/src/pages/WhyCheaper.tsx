import { Link } from 'react-router-dom';
import { TrendingDown, Package, Globe, Clock } from 'lucide-react';
import { Button } from '../components/Button';

export const WhyCheaper = () => {
  return (
    <div className="bg-white">
      {/* Hero */}
      <section className="bg-black text-white py-24">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-7xl font-black uppercase tracking-tighter mb-6">Why We're Cheaper</h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            We've disrupted the traditional fragrance retail model to bring you the scents you love for a fraction of the price.
          </p>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 mb-24">
            <div className="p-10 bg-gray-50 border border-gray-100 rounded-[2.5rem]">
              <Globe className="w-12 h-12 text-[#003366] mb-6" />
              <h3 className="text-2xl font-black uppercase tracking-widest mb-4">Direct Supplier Relationships</h3>
              <p className="text-gray-600 leading-relaxed">
                We work directly with authorized distributors and manufacturers globally. By cutting out regional wholesalers, we eliminate multiple layers of markups.
              </p>
            </div>
            <div className="p-10 bg-gray-50 border border-gray-100 rounded-[2.5rem]">
              <Package className="w-12 h-12 text-[#003366] mb-6" />
              <h3 className="text-2xl font-black uppercase tracking-widest mb-4">Bulk Inventory Purchasing</h3>
              <p className="text-gray-600 leading-relaxed">
                Our massive scale allows us to buy thousands of units at once. This volume gives us negotiating power that small boutiques and even large department stores can't match.
              </p>
            </div>
            <div className="p-10 bg-gray-50 border border-gray-100 rounded-[2.5rem]">
              <TrendingDown className="w-12 h-12 text-[#003366] mb-6" />
              <h3 className="text-2xl font-black uppercase tracking-widest mb-4">Online-Only Business Model</h3>
              <p className="text-gray-600 leading-relaxed">
                Malls charge astronomical rents. We operate from efficient distribution centers, saving millions in overhead costs which we pass directly to you.
              </p>
            </div>
          </div>

          {/* Comparison Chart */}
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-black uppercase tracking-tighter text-center mb-12">Price Comparison</h2>
            <div className="overflow-hidden border border-gray-200 rounded-[2.5rem]">
              <table className="w-full text-left">
                <thead className="bg-black text-white uppercase tracking-widest text-xs">
                  <tr>
                    <th className="p-6">Fragrance</th>
                    <th className="p-6">Mall Retail Price</th>
                    <th className="p-6 bg-[#003366]">Our Price</th>
                    <th className="p-6">You Save</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  <tr className="hover:bg-gray-50 transition-colors">
                    <td className="p-6 font-bold uppercase tracking-widest text-sm">Versace Eros (100ml)</td>
                    <td className="p-6 text-gray-400 line-through">$105.00</td>
                    <td className="p-6 font-black text-[#003366]">$72.00</td>
                    <td className="p-6 text-green-600 font-bold">$33.00 (31%)</td>
                  </tr>
                  <tr className="hover:bg-gray-50 transition-colors">
                    <td className="p-6 font-bold uppercase tracking-widest text-sm">Dior Sauvage (60ml)</td>
                    <td className="p-6 text-gray-400 line-through">$145.00</td>
                    <td className="p-6 font-black text-[#003366]">$110.00</td>
                    <td className="p-6 text-green-600 font-bold">$35.00 (24%)</td>
                  </tr>
                  <tr className="hover:bg-gray-50 transition-colors">
                    <td className="p-6 font-bold uppercase tracking-widest text-sm">Creed Aventus (100ml)</td>
                    <td className="p-6 text-gray-400 line-through">$450.00</td>
                    <td className="p-6 font-black text-[#003366]">$295.00</td>
                    <td className="p-6 text-green-600 font-bold">$155.00 (34%)</td>
                  </tr>
                  <tr className="hover:bg-gray-50 transition-colors">
                    <td className="p-6 font-bold uppercase tracking-widest text-sm">Lattafa Khamrah (100ml)</td>
                    <td className="p-6 text-gray-400 line-through">$75.00</td>
                    <td className="p-6 font-black text-[#003366]">$45.00</td>
                    <td className="p-6 text-green-600 font-bold">$30.00 (40%)</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-24 text-center">
            <h2 className="text-3xl font-black uppercase tracking-tighter mb-6">Ready to stop overpaying?</h2>
            <Link to="/shop">
              <Button size="lg">Shop All Fragrances</Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};
