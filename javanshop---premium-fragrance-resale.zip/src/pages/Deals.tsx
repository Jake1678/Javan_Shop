import { useState, useEffect } from 'react';
import { ProductCard } from '../components/ProductCard';
import { PRODUCTS } from '../constants';

export const Deals = () => {
  const dealProducts = PRODUCTS.filter(p => p.isDeal || p.price < p.retailPrice * 0.6);
  const [timeLeft, setTimeLeft] = useState({ hours: 24, minutes: 0, seconds: 0 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        if (prev.hours > 0) return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="bg-white">
      <div className="bg-[#003366] text-white py-24">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-7xl font-black uppercase tracking-tighter mb-6">Limited Time Deals</h1>
          <div className="flex justify-center gap-4 mb-8">
            <div className="bg-white/10 backdrop-blur-md px-4 py-2 border border-white/20 rounded-2xl">
              <span className="text-3xl font-black">{String(timeLeft.hours).padStart(2, '0')}</span>
              <p className="text-[10px] uppercase font-bold tracking-widest opacity-60">Hours</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md px-4 py-2 border border-white/20 rounded-2xl">
              <span className="text-3xl font-black">{String(timeLeft.minutes).padStart(2, '0')}</span>
              <p className="text-[10px] uppercase font-bold tracking-widest opacity-60">Minutes</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md px-4 py-2 border border-white/20 rounded-2xl">
              <span className="text-3xl font-black">{String(timeLeft.seconds).padStart(2, '0')}</span>
              <p className="text-[10px] uppercase font-bold tracking-widest opacity-60">Seconds</p>
            </div>
          </div>
          <p className="text-xl text-white/80 max-w-2xl mx-auto uppercase tracking-widest font-bold">
            Up to 50% off retail. When they're gone, they're gone.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-24">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {dealProducts.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        {dealProducts.length === 0 && (
          <div className="text-center py-24">
            <p className="text-gray-500 uppercase tracking-widest font-bold">New deals dropping soon. Stay tuned.</p>
          </div>
        )}
      </div>
    </div>
  );
};
