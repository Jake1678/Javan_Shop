import { useState } from 'react';
import { Plus, Minus } from 'lucide-react';

const FAQ_DATA = [
  {
    question: "Are your fragrances authentic?",
    answer: "Yes, 100%. We only source our fragrances from authorized distributors and reputable wholesalers. Every bottle comes in its original retail packaging with batch codes that can be verified."
  },
  {
    question: "How long does shipping take?",
    answer: "We process orders within 24 hours. Domestic shipping typically takes 2-4 business days. You will receive a tracking number as soon as your order ships."
  },
  {
    question: "Do you offer refunds?",
    answer: "We offer a 30-day return policy for unopened and unused fragrances. If you receive a damaged item, please contact us immediately for a replacement."
  },
  {
    question: "Where do you ship?",
    answer: "Currently, we ship to all 50 states in the US and Canada. We are looking to expand to international shipping in the near future."
  },
  {
    question: "Why are your prices so much lower than department stores?",
    answer: "We buy in massive bulk and operate exclusively online. This allows us to avoid the high overhead costs of physical retail stores and pass those savings directly to you."
  }
];

export const FAQ = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <div className="bg-white">
      <div className="bg-black text-white py-24">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-5xl font-black uppercase tracking-tighter mb-6">Frequently Asked Questions</h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto uppercase tracking-widest font-bold">
            Everything you need to know about JavanShop
          </p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-24">
        <div className="space-y-4">
          {FAQ_DATA.map((item, index) => (
            <div key={index} className="border border-gray-200 overflow-hidden rounded-2xl">
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between p-6 text-left hover:bg-gray-50 transition-colors"
              >
                <span className="text-lg font-black uppercase tracking-widest">{item.question}</span>
                {openIndex === index ? <Minus className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
              </button>
              {openIndex === index && (
                <div className="p-6 pt-0 text-gray-600 leading-relaxed border-t border-gray-100 bg-gray-50/50">
                  {item.answer}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
