import { Truck, Clock, ShieldCheck } from 'lucide-react';

export const ShippingPolicy = () => {
  return (
    <div className="bg-white">
      <div className="bg-gray-50 py-24 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-5xl font-black uppercase tracking-tighter mb-6">Shipping Policy</h1>
          <p className="text-gray-500 uppercase tracking-widest text-sm font-bold">Fast & Reliable Delivery</p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-24">
        <div className="prose prose-lg max-w-none">
          <div className="flex items-center gap-4 mb-8 p-6 bg-blue-50 border border-blue-100 rounded-3xl">
            <Clock className="w-8 h-8 text-[#003366]" />
            <div>
              <h3 className="text-xl font-black uppercase tracking-tight m-0">24-Hour Dispatch</h3>
              <p className="text-gray-600 m-0">We ship all orders within the first 24 hours of being placed.</p>
            </div>
          </div>

          <h2 className="text-3xl font-black uppercase tracking-tighter mb-6">Our Commitment</h2>
          <p className="text-gray-600 leading-relaxed mb-8">
            At JavanShop, we understand that when you order a new fragrance, you want it as soon as possible. 
            That's why we've optimized our logistics to ensure that every order is processed, packed, and 
            dispatched within 24 hours.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            <div className="p-8 bg-gray-50 border border-gray-100 rounded-3xl">
              <Truck className="w-10 h-10 mb-4 text-[#003366]" />
              <h4 className="text-lg font-black uppercase tracking-tight mb-2">Tracked Shipping</h4>
              <p className="text-sm text-gray-500">Every order comes with a tracking number so you can follow your fragrance's journey.</p>
            </div>
            <div className="p-8 bg-gray-50 border border-gray-100 rounded-3xl">
              <ShieldCheck className="w-10 h-10 mb-4 text-[#003366]" />
              <h4 className="text-lg font-black uppercase tracking-tight mb-2">Secure Packaging</h4>
              <p className="text-sm text-gray-500">We use premium, shock-absorbent packaging to ensure your bottle arrives in perfect condition.</p>
            </div>
          </div>

          <h3 className="text-2xl font-black uppercase tracking-tighter mb-4">Delivery Times</h3>
          <p className="text-gray-600 leading-relaxed mb-4">
            Once dispatched, standard shipping typically takes 3-5 business days within the continental US. 
            Expedited options are available at checkout if you need your scent even faster.
          </p>
          
          <p className="text-gray-400 text-sm italic mt-12 border-t pt-8">
            Last updated: March 2026
          </p>
        </div>
      </div>
    </div>
  );
};
