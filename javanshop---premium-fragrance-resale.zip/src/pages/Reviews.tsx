import { Star, Quote } from 'lucide-react';
import { REVIEWS } from '../constants';

export const Reviews = () => {
  return (
    <div className="bg-white">
      <div className="bg-gray-50 py-24 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-5xl font-black uppercase tracking-tighter mb-6">Customer Reviews</h1>
          <div className="flex justify-center gap-1 mb-4">
            {[...Array(5)].map((_, i) => <Star key={i} className="w-6 h-6 fill-yellow-400 text-yellow-400" />)}
          </div>
          <p className="text-gray-500 uppercase tracking-widest text-sm font-bold">Trusted by over 10,000 fragrance lovers</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {REVIEWS.map(review => (
            <div key={review.id} className="bg-white p-10 border border-gray-100 shadow-sm relative rounded-[2.5rem]">
              <Quote className="w-10 h-10 text-gray-100 absolute top-6 right-6" />
              <div className="flex gap-1 mb-6">
                {[...Array(review.rating)].map((_, i) => <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />)}
              </div>
              <p className="text-xl italic mb-8 text-gray-800 leading-relaxed">"{review.comment}"</p>
              <div className="flex items-center justify-between">
                <p className="font-black uppercase tracking-widest text-sm">— {review.author}</p>
                <p className="text-xs text-gray-400 uppercase tracking-widest">{review.date}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
