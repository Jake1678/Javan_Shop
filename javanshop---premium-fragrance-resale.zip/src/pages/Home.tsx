import { Link } from 'react-router-dom';
import { CheckCircle, ArrowRight, Star, Mail } from 'lucide-react';
import { motion } from 'motion/react';
import { Button } from '../components/Button';
import { ProductCard } from '../components/ProductCard';
import { PRODUCTS, REVIEWS } from '../constants';

export const Home = () => {
  const bestSellers = PRODUCTS.filter(p => p.isBestSeller);
  const trending = PRODUCTS.filter(p => p.isTrending);

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative h-[90vh] flex items-center overflow-hidden bg-black">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&q=80&w=2000"
            alt="Jean Paul Gaultier Le Male Elixir Style Fragrance"
            className="w-full h-full object-cover opacity-60"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/40 to-transparent" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 w-full">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-2xl"
          >
            <h1 className="text-5xl md:text-7xl font-black text-white uppercase tracking-tighter leading-[0.9] mb-6">
              Luxury Fragrances <br />
              <span className="text-gray-400">Without the</span> <br />
              Luxury Price
            </h1>
            <p className="text-xl text-gray-300 mb-8 max-w-lg">
              100% authentic designer colognes and perfumes up to 40% cheaper than retail.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/shop">
                <Button size="lg" className="w-full sm:w-auto">Shop Best Sellers</Button>
              </Link>
              <Link to="/shop">
                <Button variant="secondary" size="lg" className="w-full sm:w-auto">Browse All</Button>
              </Link>
            </div>

            <div className="mt-12 flex flex-wrap gap-6">
              <div className="flex items-center gap-2 text-white/80 text-sm font-bold uppercase tracking-widest">
                <CheckCircle className="w-5 h-5 text-[#003366]" />
                100% Authentic
              </div>
              <div className="flex items-center gap-2 text-white/80 text-sm font-bold uppercase tracking-widest">
                <CheckCircle className="w-5 h-5 text-[#003366]" />
                Fast Shipping
              </div>
              <div className="flex items-center gap-2 text-white/80 text-sm font-bold uppercase tracking-widest">
                <CheckCircle className="w-5 h-5 text-[#003366]" />
                Trusted by Hundreds
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Best Sellers */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="text-4xl font-black uppercase tracking-tighter mb-2">Featured Best Sellers</h2>
              <p className="text-gray-500 uppercase tracking-widest text-sm font-bold">The scents everyone is talking about</p>
            </div>
            <Link to="/shop" className="hidden md:flex items-center gap-2 font-bold uppercase tracking-widest text-sm hover:text-[#003366] transition-colors">
              View All <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-6">
            {bestSellers.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Why Our Prices Are Lower */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-4xl font-black uppercase tracking-tighter mb-4">How We Sell Fragrances Cheaper</h2>
            <p className="text-gray-600">We source directly from trusted distributors and buy in bulk so we can pass the savings to our customers. No middleman, no mall rent, just pure savings.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center p-8 bg-white shadow-sm border border-gray-100 rounded-3xl">
              <div className="w-16 h-16 bg-gray-100 flex items-center justify-center mx-auto mb-6 rounded-2xl">
                <CheckCircle className="w-8 h-8 text-[#003366]" />
              </div>
              <h3 className="text-xl font-bold uppercase tracking-widest mb-4">Direct Sourcing</h3>
              <p className="text-gray-500 text-sm leading-relaxed">We work directly with authorized distributors worldwide to bypass retail markups.</p>
            </div>
            <div className="text-center p-8 bg-white shadow-sm border border-gray-100 rounded-3xl">
              <div className="w-16 h-16 bg-gray-100 flex items-center justify-center mx-auto mb-6 rounded-2xl">
                <CheckCircle className="w-8 h-8 text-[#003366]" />
              </div>
              <h3 className="text-xl font-bold uppercase tracking-widest mb-4">Bulk Purchasing</h3>
              <p className="text-gray-500 text-sm leading-relaxed">Buying thousands of units at once allows us to negotiate prices that individual stores can't match.</p>
            </div>
            <div className="text-center p-8 bg-white shadow-sm border border-gray-100 rounded-3xl">
              <div className="w-16 h-16 bg-gray-100 flex items-center justify-center mx-auto mb-6 rounded-2xl">
                <CheckCircle className="w-8 h-8 text-[#003366]" />
              </div>
              <h3 className="text-xl font-bold uppercase tracking-widest mb-4">Low Overhead</h3>
              <p className="text-gray-500 text-sm leading-relaxed">By operating exclusively online, we avoid expensive mall leases and passing those costs to you.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Trending Fragrances */}
      <section className="py-24 bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 mb-12">
          <h2 className="text-4xl font-black uppercase tracking-tighter">Trending Fragrances</h2>
        </div>
        <div className="flex gap-6 overflow-x-auto pb-8 px-4 max-w-7xl mx-auto scrollbar-hide">
          {trending.map(product => (
            <div key={product.id} className="min-w-[280px]">
              <ProductCard product={product} />
            </div>
          ))}
        </div>
      </section>

      {/* Customer Reviews */}
      <section className="py-24 bg-black text-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-black uppercase tracking-tighter mb-4">What Customers Are Saying</h2>
            <div className="flex justify-center gap-1 mb-2">
              {[...Array(5)].map((_, i) => <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />)}
            </div>
            <p className="text-gray-400 uppercase tracking-widest text-sm font-bold">Over 500+ 5-star reviews</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {REVIEWS.slice(0, 3).map(review => (
              <div key={review.id} className="bg-white/5 p-8 border border-white/10 rounded-3xl">
                <div className="flex gap-1 mb-4">
                  {[...Array(review.rating)].map((_, i) => <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />)}
                </div>
                <p className="text-lg italic mb-6 text-gray-300">"{review.comment}"</p>
                <p className="font-bold uppercase tracking-widest text-sm">— {review.author}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Deals Banner */}
      <section className="py-24 bg-[#003366] text-white">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-5xl md:text-7xl font-black uppercase tracking-tighter mb-8">Limited Time <br /> Fragrance Deals</h2>
          <Link to="/deals">
            <Button variant="secondary" size="lg">Shop Deals Now</Button>
          </Link>
        </div>
      </section>

      {/* Email Capture */}
      <section className="py-24 bg-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <Mail className="w-12 h-12 mx-auto mb-6 text-[#003366]" />
          <h2 className="text-4xl font-black uppercase tracking-tighter mb-4">Get Exclusive Fragrance Deals</h2>
          <p className="text-gray-600 mb-8">Join our email list and get notified when new fragrances drop or go on sale. No spam, just savings.</p>
          <form className="flex flex-col sm:flex-row gap-4" onSubmit={(e) => e.preventDefault()}>
            <input
              type="email"
              placeholder="Enter your email address"
              className="flex-1 border-2 border-gray-200 px-6 py-4 outline-none focus:border-black transition-colors rounded-3xl"
            />
            <Button size="lg">Subscribe</Button>
          </form>
        </div>
      </section>
    </div>
  );
};
