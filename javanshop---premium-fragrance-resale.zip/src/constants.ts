import { Product, Review } from './types';

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Eros Parfum',
    brand: 'Versace',
    price: 82,
    retailPrice: 120,
    image: 'https://m.media-amazon.com/images/I/81Q0IpZzQnL._AC_UF350,350_QL80_.jpg',
    rating: 4.9,
    reviewsCount: 450,
    description: 'Love, passion, beauty, and desire are the key concepts of the new men\'s fragrance by Versace. A fragrance that interprets the sublime masculinity through a luminous aura with an intense, vibrant and glowing freshness.',
    type: 'Sweet',
    notes: {
      top: ['Mint', 'Green Apple', 'Lemon'],
      middle: ['Tonka Bean', 'Ambroxan', 'Geranium'],
      base: ['Madagascar Vanilla', 'Virginian Cedar', 'Oakmoss']
    },
    longevity: 'Strong',
    occasion: 'Date Night',
    isBestSeller: true,
    stockCount: 3,
    stripeLink: 'https://buy.stripe.com/your_link_here_3'
  },
  {
    id: '2',
    name: 'Y Eau de Parfum',
    brand: 'Yves Saint Laurent',
    price: 95,
    retailPrice: 140,
    image: 'https://m.media-amazon.com/images/I/81SABgUNwdL._AC_UF350,350_QL80_.jpg',
    rating: 4.8,
    reviewsCount: 420,
    description: 'A bold and masculine fragrance that captures the spirit of a generation. Y is not the story of an individual man, but of a generation of men: creative men who dare to follow their passions and carve their own paths.',
    type: 'Fresh',
    notes: {
      top: ['Apple', 'Ginger', 'Bergamot'],
      middle: ['Sage', 'Juniper Berries', 'Geranium'],
      base: ['Amberwood', 'Tonka Bean', 'Cedar']
    },
    longevity: 'Strong',
    occasion: 'Daily',
    isBestSeller: true,
    stockCount: 10,
    stripeLink: 'https://buy.stripe.com/your_link_here_10'
  },
  {
    id: '3',
    name: 'The One',
    brand: 'Dolce & Gabbana',
    price: 65,
    retailPrice: 95,
    image: 'https://m.media-amazon.com/images/I/71FXKnnY0OL._AC_UF350,350_QL80_.jpg',
    rating: 4.8,
    reviewsCount: 320,
    description: 'The One for Men is an elegant, sensual perfume that is decidedly modern but also a unique, timeless classic. It is the natural, masculine version of Dolce & Gabbana The One.',
    type: 'Woody',
    notes: {
      top: ['Grapefruit', 'Coriander', 'Basil'],
      middle: ['Ginger', 'Cardamom', 'Orange Blossom'],
      base: ['Tobacco', 'Amber', 'Cedar']
    },
    longevity: 'Moderate',
    occasion: 'Formal',
    isBestSeller: true,
    stockCount: 15,
    stripeLink: 'https://buy.stripe.com/your_link_here_5'
  },
  {
    id: '4',
    name: 'Bad Boy Extreme',
    brand: 'Carolina Herrera',
    price: 85,
    retailPrice: 130,
    image: 'https://static.sweetcare.com/img/prd/488/v-638681327413584305/carolina-herrera-022292cr-1.webp',
    rating: 4.7,
    reviewsCount: 156,
    description: 'A fiery evolution of the iconic Bad Boy scent that explores a daring new tension. This fragrance is a bold and sophisticated scent for men who dare to embrace all sides of their personality.',
    type: 'Spicy',
    notes: {
      top: ['Ginger', 'Bergamot'],
      middle: ['Vetiver', 'Cocoa'],
      base: ['Patchouli', 'Tonka Bean']
    },
    longevity: 'Very Strong',
    occasion: 'Formal',
    isBestSeller: true,
    stockCount: 7,
    stripeLink: 'https://buy.stripe.com/your_link_here_4'
  },
  {
    id: '5',
    name: 'Sauvage Elixir',
    brand: 'Dior',
    price: 145,
    retailPrice: 190,
    image: 'https://www.sephora.com/productimages/sku/s2615052-av-6202508270703454090700-zoom.jpg?imwidth=315',
    rating: 4.9,
    reviewsCount: 210,
    description: 'An extraordinarily concentrated fragrance steeped in the emblematic freshness of Sauvage with an intoxicating heart of spices, a "tailor-made" lavender essence and a blend of rich woods.',
    type: 'Spicy',
    notes: {
      top: ['Cinnamon', 'Nutmeg', 'Cardamom'],
      middle: ['Lavender'],
      base: ['Licorice', 'Sandalwood', 'Amber']
    },
    longevity: 'Very Strong',
    occasion: 'Formal',
    isTrending: true,
    stockCount: 4,
    stripeLink: 'https://buy.stripe.com/your_link_here_6'
  },
  {
    id: '6',
    name: 'Bleu de Chanel',
    brand: 'Chanel',
    price: 115,
    retailPrice: 150,
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSogCShIF4rakp13xrG0WIui-XoR0vYHbvvUw&s',
    rating: 4.9,
    reviewsCount: 500,
    description: 'The most intense of the BLEU DE CHANEL fragrances. Powerful and refined, BLEU DE CHANEL Parfum for men reveals the essence of determination.',
    type: 'Woody',
    notes: {
      top: ['Lemon Zest', 'Bergamot', 'Mint'],
      middle: ['Lavender', 'Pineapple', 'Geranium'],
      base: ['Sandalwood', 'Cedar', 'Amberwood']
    },
    longevity: 'Strong',
    occasion: 'Daily',
    isTrending: true,
    stockCount: 8,
    stripeLink: 'https://buy.stripe.com/your_link_here_7'
  },
  {
    id: '7',
    name: 'Le Male Elixir',
    brand: 'Jean Paul Gaultier',
    price: 110,
    retailPrice: 165,
    image: 'https://palatialscents.shop/cdn/shop/files/JPGGG.jpg?v=1705193303&width=1445',
    rating: 4.9,
    reviewsCount: 180,
    description: 'A woody aromatic fragrance for men. This is a new fragrance launched in 2023. The fragrance features lavender, mint, vanilla, benzoin, honey, tonka bean and tobacco.',
    type: 'Sweet',
    notes: {
      top: ['Lavender', 'Mint'],
      middle: ['Vanilla', 'Benzoin'],
      base: ['Honey', 'Tonka Bean', 'Tobacco']
    },
    longevity: 'Very Strong',
    occasion: 'Date Night',
    isTrending: true,
    stockCount: 6,
    stripeLink: 'https://buy.stripe.com/your_link_here_9'
  }
];

export const REVIEWS: Review[] = [
  {
    id: '1',
    author: 'Chris M.',
    rating: 5,
    comment: 'Better than Sephora. They taxin ong😭  shipping was fast too.',
    date: '2024-03-01'
  },
  {
    id: '2',
    author: 'David Henderson',
    rating: 5,
    comment: 'I was honestly a bit skeptical at first because the price seemed too good to be true, but I just got my bottle of Sauvage Elixir and it is real. Definitely coming back for more.',
    date: '2026-02-28'
  },
  {
    id: '3',
    author: 'J.T.',
    rating: 5,
    comment: 'legit.',
    date: '2026-02-25'
  },
  {
    id: '4',
    author: 'Michael R.',
    rating: 5,
    comment: 'Been looking for a good deal on Bleu de Chanel for a while now and this is the best price I\'ve found anywhere. Arrived in perfect condition and the batch code checks out. Thanks guys!',
    date: '2026-02-20'
  },
  {
    id: '5',
    author: 'Brandon',
    rating: 4,
    comment: 'Good stuff just wish the shipping was a day faster but otherwise great.',
    date: '2026-02-15'
  }
];
