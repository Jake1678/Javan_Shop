import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from './Button';

export const ExitIntentPopup = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [hasShown, setHasShown] = useState(false);

  useEffect(() => {
    const handleMouseOut = (e: MouseEvent) => {
      if (e.clientY <= 0 && !hasShown) {
        setIsVisible(true);
        setHasShown(true);
      }
    };

    document.addEventListener('mouseleave', handleMouseOut);
    return () => document.removeEventListener('mouseleave', handleMouseOut);
  }, [hasShown]);

  if (!isVisible) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white max-w-lg w-full relative overflow-hidden rounded-[2.5rem]"
        >
          <button
            onClick={() => setIsVisible(false)}
            className="absolute top-4 right-4 p-2 hover:bg-gray-100 transition-colors z-10 rounded-full"
          >
            <X className="w-6 h-6" />
          </button>

          <div className="grid grid-cols-1 md:grid-cols-2">
            <div className="hidden md:block">
              <img
                src="https://m.media-amazon.com/images/I/A11LbamXjBL.png"
                alt="Fragrance"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="p-8 flex flex-col justify-center text-center md:text-left">
              <h2 className="text-3xl font-black uppercase tracking-tighter mb-2">Wait!</h2>
              <p className="text-gray-600 mb-6">
                Don't leave empty handed. Get <span className="text-[#003366] font-bold">10% OFF</span> your first order!
              </p>
              <input
                type="email"
                placeholder="Enter your email"
                className="w-full border-2 border-gray-200 px-4 py-3 mb-4 focus:border-black outline-none transition-colors rounded-2xl"
              />
              <Button className="w-full">Get My Discount</Button>
              <button
                onClick={() => setIsVisible(false)}
                className="mt-4 text-xs text-gray-400 uppercase tracking-widest hover:text-black"
              >
                No thanks, I prefer paying full price
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
