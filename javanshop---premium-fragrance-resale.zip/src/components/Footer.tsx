import { Link } from 'react-router-dom';
import { Instagram, Mail, Phone, MapPin } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="bg-black text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
        <div>
          <Link to="/" className="text-2xl font-black tracking-tighter uppercase mb-6 block">
            Javan<span className="text-[#003366]">Shop</span>
          </Link>
          <p className="text-gray-400 text-sm leading-relaxed mb-6">
            Luxury fragrances without the luxury price. 100% authentic designer colognes and perfumes up to 40% cheaper than retail.
          </p>
          <div className="flex gap-4">
            <a 
              href="https://instagram.com/javan_co2026/" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="hover:text-[#003366] transition-colors"
            >
              <Instagram className="w-5 h-5" />
            </a>
          </div>
        </div>

        <div>
          <h4 className="text-lg font-bold uppercase tracking-widest mb-6">Quick Links</h4>
          <ul className="space-y-4 text-sm text-gray-400">
            <li><Link to="/shop" className="hover:text-white transition-colors">Shop All</Link></li>
            <li><Link to="/deals" className="hover:text-white transition-colors">Limited Deals</Link></li>
            <li><Link to="/why-cheaper" className="hover:text-white transition-colors">Why We're Cheaper</Link></li>
            <li><Link to="/reviews" className="hover:text-white transition-colors">Customer Reviews</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-lg font-bold uppercase tracking-widest mb-6">Support</h4>
          <ul className="space-y-4 text-sm text-gray-400">
            <li><Link to="/faq" className="hover:text-white transition-colors">FAQ</Link></li>
            <li><Link to="/contact" className="hover:text-white transition-colors">Contact Us</Link></li>
            <li><Link to="/shipping-policy" className="hover:text-white transition-colors">Shipping Policy</Link></li>
            <li><Link to="/refund-policy" className="hover:text-white transition-colors">Refund Policy</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-lg font-bold uppercase tracking-widest mb-6">Contact Info</h4>
          <ul className="space-y-4 text-sm text-gray-400">
            <li className="flex items-center gap-3">
              <Mail className="w-4 h-4" />
              <span>jakeconjohn5@gmail.com</span>
            </li>
            <li className="flex items-center gap-3">
              <Phone className="w-4 h-4" />
              <span>937-499-3698</span>
            </li>
            <li className="flex items-center gap-3">
              <MapPin className="w-4 h-4" />
              <span>Southwest Ohio</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-gray-500 uppercase tracking-widest">
        <p>© 2026 JavanShop. All Rights Reserved.</p>
        <div className="flex gap-6">
          <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
          <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
        </div>
      </div>
    </footer>
  );
};
