import { Link } from 'react-router-dom';
import { Star } from 'lucide-react';
import { Product } from '../types';
import { Button } from './Button';
import { motion } from 'motion/react';

interface ProductCardProps {
  product: Product;
  key?: string | number;
}

export const ProductCard = ({ product }: ProductCardProps) => {
  const discount = Math.round(((product.retailPrice - product.price) / product.retailPrice) * 100);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="group relative bg-white border border-gray-100 overflow-hidden rounded-[2.5rem]"
    >
      <Link to={`/product/${product.id}`} className="block relative aspect-[3/4] overflow-hidden bg-white rounded-t-[2.5rem] p-10">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-contain transition-transform duration-500 group-hover:scale-110"
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-4 left-4 bg-[#003366] text-white px-2 py-1 text-xs font-bold uppercase tracking-tighter">
          -{discount}% OFF
        </div>
        {product.stockCount < 10 && (
          <div className="absolute bottom-4 left-4 bg-red-600 text-white px-2 py-1 text-[10px] font-bold uppercase">
            Only {product.stockCount} left
          </div>
        )}
      </Link>

      <div className="p-4">
        <div className="flex justify-between items-start mb-1">
          <p className="text-xs text-gray-500 uppercase tracking-widest">{product.brand}</p>
          <div className="flex items-center gap-1">
            <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
            <span className="text-xs font-medium">{product.rating}</span>
          </div>
        </div>
        <Link to={`/product/${product.id}`} className="block">
          <h3 className="text-lg font-bold text-black mb-2 group-hover:text-[#003366] transition-colors">
            {product.name}
          </h3>
        </Link>
        <div className="flex items-baseline gap-2 mb-4">
          <span className="text-xl font-black text-black">${product.price}</span>
          <span className="text-sm text-gray-400 line-through">${product.retailPrice}</span>
        </div>
        <Button 
          className="w-full text-xs py-2" 
          size="sm"
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            if (product.stripeLink) {
              window.location.href = product.stripeLink;
            }
          }}
        >
          Buy Now
        </Button>
      </div>
    </motion.div>
  );
};
