import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X, Search, User, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
    setIsSearchOpen(false);
  }, [location]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/shop?q=${encodeURIComponent(searchQuery.trim())}`);
      setIsSearchOpen(false);
      setSearchQuery('');
    }
  };

  const navLinks = [
    { name: 'Shop', path: '/shop' },
    { name: 'Deals', path: '/deals' },
    { name: 'Why Us', path: '/why-cheaper' },
    { name: 'Reviews', path: '/reviews' },
    { name: 'FAQ', path: '/faq' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <>
      <div className="bg-black text-white py-2 text-center text-xs font-bold uppercase tracking-[0.2em]">
        FREE SHIPPING UNTIL MARCH 31st
      </div>
      <nav
        className={`sticky top-0 z-50 transition-all duration-300 ${
          isScrolled ? 'bg-white shadow-md py-2' : 'bg-white/90 backdrop-blur-md py-4'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between">
          <div className="flex items-center gap-4 lg:hidden">
            <button onClick={() => setIsOpen(true)} className="p-2">
              <Menu className="w-6 h-6" />
            </button>
          </div>

          <Link to="/" className="text-2xl font-black tracking-tighter uppercase">
            Javan<span className="text-[#003366]">Shop</span>
          </Link>

          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`text-sm font-bold uppercase tracking-widest hover:text-[#003366] transition-colors ${
                  location.pathname === link.path ? 'text-[#003366]' : 'text-black'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </div>

          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSearchOpen(true)}
              className="p-2 hover:text-[#003366] transition-colors"
            >
              <Search className="w-5 h-5" />
            </button>
            <button className="p-2 hover:text-[#003366] transition-colors">
              <User className="w-5 h-5" />
            </button>
          </div>
        </div>
      </nav>

      <AnimatePresence>
        {isSearchOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-[100] bg-white p-4 md:p-8"
          >
            <div className="max-w-3xl mx-auto">
              <div className="flex justify-end mb-8">
                <button onClick={() => setIsSearchOpen(false)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                  <X className="w-8 h-8" />
                </button>
              </div>
              <form onSubmit={handleSearch} className="relative">
                <input
                  autoFocus
                  type="text"
                  placeholder="Search for fragrances, brands..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full text-3xl md:text-5xl font-black uppercase tracking-tighter border-b-4 border-black pb-4 outline-none placeholder:text-gray-200"
                />
                <button type="submit" className="absolute right-0 bottom-6">
                  <Search className="w-8 h-8 md:w-12 md:h-12" />
                </button>
              </form>
              <div className="mt-12">
                <p className="text-xs font-black uppercase tracking-widest text-gray-400 mb-4">Popular Searches</p>
                <div className="flex flex-wrap gap-3">
                  {['Lattafa', 'Jean Paul Gaultier', 'Fresh', 'Sweet'].map((term) => (
                    <button
                      key={term}
                      onClick={() => {
                        setSearchQuery(term);
                        navigate(`/shop?q=${encodeURIComponent(term)}`);
                        setIsSearchOpen(false);
                        setSearchQuery('');
                      }}
                      className="px-4 py-2 bg-gray-100 hover:bg-black hover:text-white rounded-3xl text-sm font-bold uppercase tracking-widest transition-all"
                    >
                      {term}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 bg-black/50 z-[60] backdrop-blur-sm"
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed inset-y-0 left-0 w-[80%] max-w-sm bg-white z-[70] p-6 shadow-2xl"
            >
              <div className="flex justify-between items-center mb-8">
                <Link to="/" className="text-2xl font-black tracking-tighter uppercase">
                  Javan<span className="text-[#003366]">Shop</span>
                </Link>
                <button onClick={() => setIsOpen(false)} className="p-2">
                  <X className="w-6 h-6" />
                </button>
              </div>
              <div className="flex flex-col gap-6">
                {navLinks.map((link) => (
                  <Link
                    key={link.path}
                    to={link.path}
                    className="flex items-center justify-between text-lg font-bold uppercase tracking-widest border-b border-gray-100 pb-4"
                  >
                    {link.name}
                    <ChevronRight className="w-5 h-5 text-gray-400" />
                  </Link>
                ))}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};
