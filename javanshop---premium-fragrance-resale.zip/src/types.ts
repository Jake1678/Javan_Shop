export interface Product {
  id: string;
  name: string;
  brand: string;
  price: number;
  retailPrice: number;
  image: string;
  rating: number;
  reviewsCount: number;
  description: string;
  type: 'Fresh' | 'Sweet' | 'Woody' | 'Spicy';
  notes: {
    top: string[];
    middle: string[];
    base: string[];
  };
  longevity: 'Moderate' | 'Strong' | 'Very Strong';
  occasion: 'Daily' | 'Date Night' | 'Formal';
  isBestSeller?: boolean;
  isTrending?: boolean;
  isDeal?: boolean;
  stockCount: number;
  stripeLink?: string;
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  comment: string;
  date: string;
  productName?: string;
}
